# **BD_Finance – Next-Generation Financial Advisor App (PRD)**  
**Author:** Bruno Dias (BD)  
**Version:** 3.0  
**Scope:** Design and functional requirements for the Android-based BD_Finance Advisor — an intelligent, explainable financial assistant combining data analytics, AI insights, and automated reporting.

---

## **1. Product Vision**
Deliver a **personal financial advisor in your pocket** — a mobile platform that merges **quantitative market analytics**, **qualitative AI insights**, and **macro awareness** into one trusted app.  
BD_Finance empowers users to make confident, data-backed investment decisions through **transparency, education, and automation**.

### **Core Value Proposition**
- **Accessible intelligence:** Institutional-grade analytics made simple.  
- **Explainable advice:** Every recommendation shows its reasoning path.  
- **Continuous learning:** Adapts to user portfolio, behaviour, and market trends.  
- **Offline-ready reliability:** Works even with intermittent connectivity.

---

## **2. Target Users & Personas**

| Persona | Description | Needs |
|----------|--------------|--------|
| **Retail Investor** | Individual investor managing personal portfolio. | Clear Buy/Sell/Hold guidance, alerts, performance analytics. |
| **Financial Advisor** | Professional guiding multiple clients. | Shareable reports, explainable reasoning, risk alerts. |
| **Analyst / Enthusiast** | Data-driven user wanting deeper insights. | Technical charts, model transparency, exportable data. |
| **Beginner** | Novice investor learning market basics. | Educational tooltips, simplified AI explanations. |

---

## **3. Product Goals**
1. Provide **trustworthy financial recommendations** backed by transparent metrics.  
2. Integrate **AI co-pilots** for both market commentary and personalised portfolio advice.  
3. Maintain **<4s response time** per ticker with local caching and async design.  
4. Offer **cross-platform parity** (mobile ↔ desktop) through unified APIs.  
5. Deliver a **holistic investment view** — fundamentals, technicals, macro, and sentiment.

---

## **4. System Overview**

### **Architecture Layers**
1. **Client (Android)** — Kotlin/Jetpack Compose UI with Material 3 design.  
2. **Service Layer** — Python backend (FastAPI) with unified analysis API.  
3. **Data Layer** — Connectors (Yahoo, FMP, Alpha Vantage, Finnhub) with Room/SQLite cache.  
4. **AI Layer** — LLM summarization (Groq → Gemini fallback) for narrative commentary.  
5. **Visualization Layer** — Mermaid/FlowchartJS engine for explainable diagrams.  

### **Key Modules**
- **Stock Evaluator** – Deterministic verdict (Buy, Hold, Sell) using weighted metrics.  
- **Fundamental Analyzer** – Multi-source valuation and profitability scoring.  
- **Technical Toolkit** – Indicators: MACD, RSI, ADX, Bollinger, trendline detection.  
- **Macro Dashboard** – Economic indicators (CPI, GDP, rates, yield curve, sentiment).  
- **AI Advisor** – Personalised recommendations and reasoning in natural language.  
- **Portfolio Tracker** – Imports holdings, computes exposure, CAGR, Sharpe, alerts.  
- **Learning Layer** – Embedded micro-lessons explaining terms, metrics, and logic.

---

## **5. Functional Requirements**

### **5.1 Input & Data Handling**
- Validate ticker symbols, normalise to uppercase.  
- Fetch live & historical data from primary and fallback APIs.  
- TTL cache (10 min local, 24h historical fundamentals).  
- Scheduler (WorkManager) auto-refreshes core metrics daily.  

### **5.2 Evaluation Engine**
- Compute financial ratios (P/E, P/B, ROE, ROA, EPS growth).  
- Run scoring rules with adjustable thresholds.  
- Aggregate into overall **verdict** with confidence % and reasoning path.  
- Store each metric's decision node for flowchart rendering.

### **5.3 AI Features**
- **Groq Assistant:** Generates qualitative summary (markdown → HTML).  
- **Gemini Fallback:** Handles commentary or sentiment scoring when Groq unavailable.  
- **Natural-Language Screener:** Query-based filtering (e.g., *"cheap tech stocks with ROE>15%"*).  
- **Personal Advisor Mode:** Learns portfolio preferences to generate tailored insights.  

### **5.4 Visualization**
- Generate **Mermaid flowcharts** showing decision path and verdict logic.  
- Animate active branches and risk indicators.  
- Render tooltips for metric explanations.  
- Provide accessible dark/light themes.

### **5.5 Portfolio & Reporting**
- Import portfolios (CSV/XLS).  
- Compute weighted returns, alpha/beta, Sharpe, volatility.  
- Export/share one-page PDF summaries.  
- Watchlist alerts for thresholds or earnings events.  

### **5.6 Macro & Sentiment**
- Pull global indicators (GDP, CPI, PMI, Fed rate, VIX).  
- Correlate macro shifts with portfolio risk levels.  
- Display region-specific heatmaps and trend arrows.  

### **5.7 Education Layer**
- Add dynamic tooltips on financial terms.  
- Offer interactive guides explaining ratios and flowchart nodes.  
- AI Q&A chatbot for market and investing concepts.  

---

## **6. Non-Functional Requirements**

| Category | Requirement |
|-----------|-------------|
| **Performance** | <4s response time for 95% of tickers; <10s for portfolio sync. |
| **Reliability** | 99% uptime; failover between APIs and AI providers. |
| **Security** | API keys in BuildConfig; encrypted storage for tokens. |
| **Scalability** | Modular microservice backend; local+cloud caching layers. |
| **Observability** | Structured logs, latency tracking, and cache metrics. |
| **Accessibility** | WCAG-compliant color contrast and dynamic text sizes. |
| **Internationalization** | English + Portuguese (pt-PT) at launch. |

---

## **7. Success Metrics**
- 90% of analyses completed with both flowchart + AI explanation.  
- 95% daily refresh success for tracked portfolios.  
- 80% alignment between AI and quantitative ratings.  
- 4.5+ Play Store rating with >5,000 MAUs within first year.  
- <1% crash rate based on Firebase telemetry.  

---

## **8. Risks & Mitigation**
| Risk | Mitigation |
|------|-------------|
| API rate-limits | Local caching, multi-provider fallback. |
| LLM latency | Timeout with cached summaries. |
| Outdated metrics | Scheduled background sync. |
| Overly complex UI | Progressive disclosure (basic vs advanced views). |
| AI hallucinations | Enforce numeric grounding + human-readable disclaimers. |

---

## **9. Future Enhancements**
- Predictive analytics (earnings surprises, short interest).  
- Voice-based interactions (“Hey BD, analyse Tesla”).  
- Portfolio rebalancing suggestions.  
- Integration with broker APIs for trade simulation.  
- Social sentiment overlay (Reddit, X/Twitter, SeekingAlpha).  

---

## **10. Technical Stack**

| Layer | Technology |
|-------|-------------|
| **Frontend (App)** | Kotlin, Jetpack Compose, Material 3, Android 14 SDK |
| **Backend** | Python (FastAPI), pandas, numpy, SQLAlchemy |
| **AI** | Groq LLaMA 3, Gemini 1.5 Pro (OpenAI-compatible) |
| **Storage** | SQLite (mobile), PostgreSQL (cloud optional) |
| **Visualization** | Mermaid.js (WebView), FlowchartJS |
| **Automation** | WorkManager (Android), cron (backend) |

---

## **11. TL;DR (Resumo em português)**
O **BD_Finance Advisor** é uma aplicação Android de próxima geração que atua como um **consultor financeiro inteligente**, unindo análise quantitativa, insights de IA e contexto macroeconómico. Oferece recomendações explicáveis, relatórios automáticos e educação integrada. Trabalha offline, sincroniza com o desktop e é projetado para decisões rápidas, seguras e transparentes.
