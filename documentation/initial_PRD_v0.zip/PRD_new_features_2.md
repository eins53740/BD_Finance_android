# BD_Finance Stock Analysis Platform - PRD (Version 2)

**Author:** Bruno Dias (BD)
**Scope:** BD_Finance_android v2 feature roadmap (additions layered on top of the existing APK without removing current functionality).

---

## Product Vision
Deliver a comprehensive, data-driven investment assistant that blends quantitative analysis, qualitative assessment, macro context, and automation across desktop and Android surfaces. Version 2 expands the present APK by widening data sources, deepening analytics, and enriching AI guidance while keeping today’s workflow intact.

---

## Core Philosophy
1. Quality at a discount - continue highlighting fundamentally strong companies trading below intrinsic value.
2. Holistic evaluation - extend beyond fundamentals to cover technicals, macro indicators, and qualitative moats.
3. Automation first - streamline collection, scoring, and reporting so investors focus on decisions, not data wrangling.
4. Transparent metrics - every score, alert, and AI insight must show its underlying data trail.

---

## Epic Overview (New in v2)
> Existing v1 capabilities (ticker intake, evaluation engine, Mermaid flow, LLM second opinion) must remain untouched. New features should integrate with, not replace, the current codebase.

### Epic 1 - Multi-Source Data Collection & Normalisation
_Status: ✅ Completed for v0.2 (Yahoo + Alpha Vantage connectors, normalization layer, Room cache, and scheduled refresh validated with clean lint/tests)_
**Goal:** Enrich the Android client's data via a unifying service that consolidates Yahoo, Alpha Vantage, Finnhub/FMP, and optional CSV imports.
- [x] F1.1 Data Connectors - Add modular adapters with secure API key management.
- [x] F1.2 Normalisation Layer - Standardise ratios (EPS, PE, PEG, EV/EBIT, P/B, FCF yield) into a shared schema stored in SQLite/on-device cache.
- [x] F1.3 Scheduler Hooks - Support automated refresh jobs (WorkManager on Android; optional cron for desktop backend) feeding the APK through a sync API.
    **Validation:** Run `./gradlew lint test`; inspect `app/build/reports/lint-results-debug.html`; trigger `StockMetricsSyncScheduler.schedule` at app start and confirm `stock_metrics.db` persists merged Yahoo/Alpha Vantage values via Room inspector.

### Epic 2 - Fundamental Analysis Extensions
**Goal:** Expand valuation, profitability, and growth scoring while keeping the existing verdict logic.
- F2.1 Enhanced Valuation Scoring - Weighted scores comparing ratios to sector medians and 10-year averages.
- F2.2 Profitability & Stability - Add ROE, ROA, margin consistency, leverage metrics.
- F2.3 Growth Trends - Render 5Y/10Y CAGR for revenue, EPS, FCF with acceleration/decay indicators.
- F2.4 Intrinsic Value Models - Implement DCF, Ben Graham, and DDM calculators surfaced alongside the current decision verdict.
- F2.5 Historical Context - Show deviations from historical averages (e.g., current P/E vs decade mean).

**Implementation Notes (pending approval):**
**Epic 2 Status (v0.2 implementation):**
- [x] Sector medians + historical fundamentals persisted via FMP/Alpha Vantage connectors and Room migrations.
- [x] Fundamental scorecard calculates valuation, profitability, stability, and growth metrics without altering verdict logic.
- [x] Intrinsic value models (DCF, Ben Graham, DDM) surface normalized bands alongside decision verdict.
- [x] UI adds scorecard, growth trends, valuation bands, and metadata notes in the analysis view.
- [x] Added unit coverage for data sync connectors and fundamental calculators with deterministic fixtures.


- **Data feeds & reliability:** Anchor sector medians/averages on FMP as the primary source with Alpha Vantage fallback when the FMP quota is exhausted. Wrap requests with exponential backoff and surface retry counts to the normalization service so the UI can flag stale sector data. Document rate-limit ceilings and refresh cadence (hourly for current ratios, weekly for decade medians).
- **Historical fundamentals storage:** Persist 5Y and 10Y time-series per metric (P/E, P/B, ROE, operating margin, net margin) as compressed JSON blobs keyed by ticker + metric + horizon. Store both raw yearly points and pre-computed medians so simple deltas stay O(1). Backfill on first sync and record the snapshot date to make cache invalidation explicit.
- **Normalization & scoring formulas:** Keep verdict logic unchanged by introducing a parallel `fundamentalScore` payload. Valuation scoring blends current vs sector (60%) and current vs 10Y (40%) deltas with z-score caps at ±3 to tame outliers. Clarify weighting in README and surface overrides via `FundamentalConfigOverrides.applyJson` so QA/product can tweak weighting, clamps, or valuation assumptions without a redeploy. Guard against divide-by-zero by short-circuiting to neutral scores when denominators are null.
- **Profitability & stability calculations:** Standardize ROE, ROA, debt-to-equity, and margin variance within the normalized dataset. Flag missing components (e.g., absent equity value) and propagate "insufficient data" tags down to the scoring engine to avoid misleading positives.
- **Intrinsic value assumptions:** Use a shared discount-rate helper defaulting to `max(8%, risk_free + 5%)`, cap growth at 15%, and union the calculators behind a common interface. When cash flows or dividends are negative/zero, degrade gracefully with an explanatory status string instead of showing inflated valuations.
- **UI presentation:** Start with textual "current vs average" diffs and band labels (Cheap/Fair/Expensive) to limit Compose chart churn. Leave room for charts in v2.1 once the data stabilises. Cards must show the data timestamp and data quality badge ("live", "cached", "fallback").
- **Testing & tooling:** Add contract tests for the new provider adapters, deterministic fixtures for sector + decade data, and snapshot/unit tests covering valuation bands and missing-data paths. Update lint configs only if new detectors block the build; otherwise keep existing tooling untouched.

### Epic 3 - Technical & Momentum Toolkit
**Goal:** Provide entry/exit timing insight to complement fundamentals.
- F3.1 Indicator Suite - Compute MACD, RSI, ADX, Bollinger Bands, moving averages with Compose chart tabs.
- F3.2 Pattern Detection - Identify support/resistance, Fibonacci levels, trendlines.
- F3.3 Signal Generator - Combine technical signals with the verdict to produce Buy/Hold/Sell cues.
- F3.4 Performance Metrics - Add drawdown, Sharpe, and Calmar ratios per ticker.

### Epic 4 - Macro & Market Context
**Goal:** Incorporate macro indicators into decision-making.
- F4.1 Macro Dashboard - Pull GDP growth, CPI, Fed funds rate, yield curve spreads.
- F4.2 Recession Signals - Track Sahm Rule, yield curve inversion, Buffett indicator with alert badges.
- F4.3 Sentiment Tracking - Monitor global valuations and institutional flows.
- F4.4 Forecast Alignment - Correlate macro shifts (rates, EPS trends) with target tickers.

### Epic 5 - Qualitative & Moat Evaluation
**Goal:** Layer qualitative moat scoring into reports.
- F5.1 Moat Framework - Score switching costs, network effects, intangible assets, cost advantage, efficient scale (manual inputs plus AI summaries).
- F5.2 Ownership Trends - Display institutional and insider ownership charts (Alpha Vantage/FMP).
- F5.3 Management Quality - Extract KPIs from 10-Ks/annual letters via text mining.

### Epic 6 - Portfolio & Reporting Automation
**Goal:** Move beyond single-ticker analysis.
- F6.1 Holdings Import - Accept CSV/Excel holdings, calculate sector exposure and position weights.
- F6.2 Performance Analytics - Compute CAGR, alpha vs S&P500, beta-adjusted returns.
- F6.3 Automated Reports - Generate daily PDFs/emails summarising portfolio changes, valuation alerts, macro context.
- F6.4 Watchlist Alerts - Notify when fundamentals or technicals hit custom thresholds.

### Epic 7 - UX & Platform Integration
**Goal:** Deliver a cohesive cross-platform experience.
- F7.1 Desktop Overview - Streamlit/React dashboard combining fundamentals, technicals, macro.
- F7.2 Per-Ticker Report - Printable one-page analysis integrating new metrics and the existing Mermaid flow.
- F7.3 Chart Explorer - Interactive ratio history and TA charts.
- F7.4 Sync Layer - Share SQLite/REST payloads so desktop and Android remain aligned.

### Epic 8 - AI & Automation Layer (v2 Enhancements)
**Goal:** Upgrade AI capabilities beyond the current second opinion.
- F8.1 Financial Summary Agent - Use Groq/Gemini to summarise the expanded metrics with a 1-10 rating rationale.
- F8.2 Market Commentary Bot - Generate daily/weekly macro and sentiment summaries.
- F8.3 Natural-Language Screener - Handle queries like "find cheap tech stocks with ROE > 15% and low debt."
- F8.4 Optional Predictive Models - Integrate ML for sentiment scoring or short-term momentum forecasts.

### Epic 9 - Architecture & Infrastructure
**Goal:** Keep the platform modular and maintainable.
- F9.1 Core Python Modules - `bd_finance_core` (analysis engine) and `bd_finance_report` (outputs) reusable by desktop and Android backends.
- F9.2 Storage Options - SQLite for local, optional PostgreSQL/cloud sync.
- F9.3 API Gateway - Unified access to external providers with rate-limit handling.
- F9.4 Deployment Tooling - PyInstaller/CI scripts for packaging dashboards and services.

---

## Tech Stack Summary
| Layer          | Technologies                                                   |
|---------------|----------------------------------------------------------------|
| Backend        | Python (pandas, numpy, SQLAlchemy, yfinance, FMP, Alpha Vantage) |
| Automation     | Cron/WorkManager, SMTP, PyInstaller                            |
| AI Integration | Groq LLaMA 3, Gemini 1.5, OpenAI-compatible APIs               |
| Storage        | SQLite (device), CSV, optional PostgreSQL                      |
| Frontend       | Android (Kotlin/Compose), Streamlit/React dashboard            |

---

## Success Metrics (v2 Targets)
- >= 95% automated daily refresh success rate.
- Portfolio + intrinsic value computation < 10 seconds per run.
- 100% coverage of primary valuation and technical metrics for tracked tickers.
- AI rating alignment with deterministic scoring >= 80%.
- Positive user feedback on expanded insights and transparency.

---

## Resumo (TL;DR em portugues)
A versao 2 da BD_Finance evolui a aplicacao com conectores multi-fontes, analises fundamentais, tecnicas e macroeconomicas mais profundas, avaliacao qualitativa de vantagens competitivas, relatorios automatizados e integracao de IA mais robusta. Mantemos a filosofia de "qualidade a bom preco", garantindo transparencia e automacao, enquanto sincronizamos dashboards desktop e app Android.
